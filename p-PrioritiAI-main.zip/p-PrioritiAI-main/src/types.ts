export interface Task {
  id: string;
  title: string;
  description?: string;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'completed';
  createdAt: number;
  aiPriorityScore?: number;
  aiReasoning?: string;
}

export type Page = 'landing' | 'dashboard' | 'about';
