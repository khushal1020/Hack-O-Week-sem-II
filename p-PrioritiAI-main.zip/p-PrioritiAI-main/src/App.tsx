import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, 
  Circle, 
  Plus, 
  Sparkles, 
  Trash2, 
  ChevronRight, 
  LayoutDashboard, 
  Info, 
  Home,
  Menu,
  X,
  ArrowRight,
  Zap,
  Shield,
  Clock
} from 'lucide-react';
import { Task, Page } from './types';
import { prioritizeTasks } from './services/gemini';

// --- Components ---

const Navbar = ({ currentPage, setPage }: { currentPage: Page, setPage: (p: Page) => void }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-black/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setPage('landing')}>
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
              <Sparkles className="text-white w-5 h-5" />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900">PrioritiAI</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => setPage('landing')} className={`text-sm font-medium ${currentPage === 'landing' ? 'text-indigo-600' : 'text-slate-600 hover:text-slate-900'}`}>Home</button>
            <button onClick={() => setPage('dashboard')} className={`text-sm font-medium ${currentPage === 'dashboard' ? 'text-indigo-600' : 'text-slate-600 hover:text-slate-900'}`}>Dashboard</button>
            <button onClick={() => setPage('about')} className={`text-sm font-medium ${currentPage === 'about' ? 'text-indigo-600' : 'text-slate-600 hover:text-slate-900'}`}>About</button>
            <button 
              onClick={() => setPage('dashboard')}
              className="bg-indigo-600 text-white px-4 py-2 rounded-full text-sm font-medium hover:bg-indigo-700 transition-colors"
            >
              Get Started
            </button>
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-slate-600 p-2">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="md:hidden bg-white border-b border-black/5 px-4 py-4 space-y-4"
          >
            <button onClick={() => { setPage('landing'); setIsOpen(false); }} className="block w-full text-left text-slate-600 font-medium">Home</button>
            <button onClick={() => { setPage('dashboard'); setIsOpen(false); }} className="block w-full text-left text-slate-600 font-medium">Dashboard</button>
            <button onClick={() => { setPage('about'); setIsOpen(false); }} className="block w-full text-left text-slate-600 font-medium">About</button>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const LandingPage = ({ onStart }: { onStart: () => void }) => {
  return (
    <div className="pt-24 pb-16">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 text-indigo-600 text-xs font-semibold mb-6">
            <Sparkles className="w-3 h-3" />
            Now with AI-Powered Task Prioritization
          </span>
          <h1 className="text-5xl md:text-7xl font-bold text-slate-900 tracking-tight mb-6">
            Master Your Day, <br />
            <span className="text-indigo-600">One Task at a Time</span>
          </h1>
          <p className="max-w-2xl mx-auto text-lg text-slate-600 mb-10">
            The ultra-fast productivity hub for high-performers. Seamlessly manage projects, tasks, and wellness routines in one beautiful interface.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button 
              onClick={onStart}
              className="w-full sm:w-auto bg-indigo-600 text-white px-8 py-4 rounded-2xl text-lg font-semibold hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-200"
            >
              Get Started for Free <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </motion.div>
      </section>

      {/* Features Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Designed for Focus</h2>
          <p className="text-slate-600">Ditch the cluttered interfaces. Our streamlined task management system puts what matters front and center.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { icon: Zap, title: "Fast AI Responses", desc: "Get instant prioritization suggestions powered by Gemini 3.1 Flash Lite." },
            { icon: Shield, title: "Secure & Private", desc: "Your tasks are yours. We prioritize data security and privacy in every feature." },
            { icon: Clock, title: "Smart Scheduling", desc: "Automatically organize your day based on deadlines and task complexity." }
          ].map((feature, i) => (
            <motion.div 
              key={i}
              whileHover={{ y: -5 }}
              className="p-8 bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all"
            >
              <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center mb-6">
                <feature.icon className="text-indigo-600 w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">{feature.title}</h3>
              <p className="text-slate-600 leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
};

const DashboardPage = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [newTask, setNewTask] = useState('');
  const [isPrioritizing, setIsPrioritizing] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('prioritiai-tasks');
    if (saved) setTasks(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('prioritiai-tasks', JSON.stringify(tasks));
  }, [tasks]);

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.trim()) return;
    const task: Task = {
      id: Math.random().toString(36).substr(2, 9),
      title: newTask,
      priority: 'medium',
      status: 'pending',
      createdAt: Date.now()
    };
    setTasks([task, ...tasks]);
    setNewTask('');
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, status: t.status === 'pending' ? 'completed' : 'pending' } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const handlePrioritize = async () => {
    if (tasks.length === 0) return;
    setIsPrioritizing(true);
    const priorities = await prioritizeTasks(tasks.filter(t => t.status === 'pending'));
    
    setTasks(prev => prev.map(t => {
      const p = priorities.find(item => item.id === t.id);
      if (p) {
        return {
          ...t,
          aiPriorityScore: p.score,
          aiReasoning: p.reasoning,
          priority: p.score > 80 ? 'high' : p.score > 40 ? 'medium' : 'low'
        };
      }
      return t;
    }).sort((a, b) => (b.aiPriorityScore || 0) - (a.aiPriorityScore || 0)));
    
    setIsPrioritizing(false);
  };

  return (
    <div className="pt-24 pb-16 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Feature Highlight Banner */}
      <motion.div 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-indigo-600 text-white p-4 rounded-2xl mb-8 flex items-center justify-between gap-4 shadow-lg shadow-indigo-100"
      >
        <div className="flex items-center gap-3">
          <div className="bg-white/20 p-2 rounded-xl">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <p className="text-sm font-bold">New: AI Smart Prioritization</p>
            <p className="text-xs text-indigo-100">Click "Smart Prioritize" to let Gemini organize your day.</p>
          </div>
        </div>
        <button 
          onClick={() => window.open('https://ai.google.dev', '_blank')}
          className="text-xs font-bold bg-white text-indigo-600 px-3 py-1.5 rounded-lg hover:bg-indigo-50 transition-colors"
        >
          Learn More
        </button>
      </motion.div>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Today's Focus</h1>
          <p className="text-slate-500">{new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>
        </div>
        <button 
          onClick={handlePrioritize}
          disabled={isPrioritizing || tasks.filter(t => t.status === 'pending').length === 0}
          className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-2xl font-semibold hover:bg-indigo-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-indigo-100"
        >
          <Sparkles className={`w-5 h-5 ${isPrioritizing ? 'animate-pulse' : ''}`} />
          {isPrioritizing ? 'AI Prioritizing...' : 'Smart Prioritize'}
        </button>
      </div>

      <form onSubmit={addTask} className="mb-8">
        <div className="relative">
          <input 
            type="text" 
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            placeholder="Add a new task..."
            className="w-full bg-white border border-slate-200 rounded-2xl px-6 py-4 pr-16 text-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all shadow-sm"
          />
          <button 
            type="submit"
            className="absolute right-2 top-2 bottom-2 bg-slate-900 text-white px-4 rounded-xl hover:bg-slate-800 transition-colors"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>
      </form>

      <div className="space-y-3">
        <AnimatePresence mode="popLayout">
          {tasks.map((task) => (
            <motion.div 
              key={task.id}
              layout
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={`group bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-start gap-4 transition-all ${task.status === 'completed' ? 'opacity-60' : ''}`}
            >
              <button 
                onClick={() => toggleTask(task.id)}
                className={`mt-1 transition-colors ${task.status === 'completed' ? 'text-emerald-500' : 'text-slate-300 hover:text-indigo-500'}`}
              >
                {task.status === 'completed' ? <CheckCircle2 className="w-6 h-6" /> : <Circle className="w-6 h-6" />}
              </button>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className={`font-semibold text-slate-900 truncate ${task.status === 'completed' ? 'line-through' : ''}`}>
                    {task.title}
                  </h3>
                  {task.aiPriorityScore && (
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                      task.priority === 'high' ? 'bg-rose-50 text-rose-600' : 
                      task.priority === 'medium' ? 'bg-amber-50 text-amber-600' : 
                      'bg-slate-50 text-slate-600'
                    }`}>
                      {task.priority}
                    </span>
                  )}
                </div>
                {task.aiReasoning && (
                  <p className="text-xs text-slate-500 italic flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-indigo-400" />
                    {task.aiReasoning}
                  </p>
                )}
              </div>

              <button 
                onClick={() => deleteTask(task.id)}
                className="opacity-0 group-hover:opacity-100 p-2 text-slate-400 hover:text-rose-500 transition-all"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {tasks.length === 0 && (
          <div className="text-center py-20 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
            <LayoutDashboard className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500 font-medium">No tasks yet. Start by adding one above!</p>
          </div>
        )}
      </div>
    </div>
  );
};

const AboutPage = () => {
  return (
    <div className="pt-24 pb-16 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-4xl font-bold text-slate-900 mb-8">About PrioritiAI</h1>
        <div className="prose prose-slate max-w-none space-y-6 text-slate-600 leading-relaxed">
          <p className="text-lg">
            PrioritiAI was born from a simple observation: most todo lists are just graveyards for tasks. We don't need more lists; we need better focus.
          </p>
          <div className="bg-indigo-50 p-8 rounded-3xl border border-indigo-100">
            <h3 className="text-indigo-900 font-bold text-xl mb-4">Our Mission</h3>
            <p className="text-indigo-800/80">
              To empower individuals to reclaim their time by leveraging cutting-edge AI to identify what truly matters. We believe that productivity isn't about doing more, but about doing the right things.
            </p>
          </div>
          <h2 className="text-2xl font-bold text-slate-900 pt-4">How it Works</h2>
          <p>
            Our core technology uses the Gemini 3.1 Flash Lite model to analyze your task list. It looks at the language you use, the complexity of the tasks, and common patterns of urgency to suggest a priority score.
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li><strong>Natural Language Processing:</strong> Understands the context of your tasks.</li>
            <li><strong>Intelligent Scoring:</strong> Assigns a 1-100 priority score based on impact.</li>
            <li><strong>Transparent Reasoning:</strong> Explains exactly why a task was prioritized.</li>
          </ul>
        </div>
      </motion.div>
    </div>
  );
};

export default function App() {
  const [page, setPage] = useState<Page>('landing');

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-sans selection:bg-indigo-100 selection:text-indigo-900">
      <Navbar currentPage={page} setPage={setPage} />
      
      <main>
        <AnimatePresence mode="wait">
          {page === 'landing' && (
            <motion.div
              key="landing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <LandingPage onStart={() => setPage('dashboard')} />
            </motion.div>
          )}
          {page === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <DashboardPage />
            </motion.div>
          )}
          {page === 'about' && (
            <motion.div
              key="about"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <AboutPage />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="border-t border-black/5 py-12 bg-white mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-indigo-600 rounded flex items-center justify-center">
                <Sparkles className="text-white w-4 h-4" />
              </div>
              <span className="text-lg font-bold text-slate-900">PrioritiAI</span>
            </div>
            <div className="flex gap-8 text-sm text-slate-500">
              <button onClick={() => setPage('about')} className="hover:text-indigo-600 transition-colors">Privacy Policy</button>
              <button onClick={() => setPage('about')} className="hover:text-indigo-600 transition-colors">Terms of Service</button>
              <button onClick={() => setPage('about')} className="hover:text-indigo-600 transition-colors">Contact</button>
            </div>
            <p className="text-sm text-slate-400">© 2024 PrioritiAI Inc. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
