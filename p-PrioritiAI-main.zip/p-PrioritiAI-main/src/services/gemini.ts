import { GoogleGenAI, Type } from "@google/genai";
import { Task } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function prioritizeTasks(tasks: Task[]): Promise<{ id: string; score: number; reasoning: string }[]> {
  if (tasks.length === 0) return [];

  const prompt = `Analyze the following tasks and prioritize them based on urgency and importance. 
  Return a JSON array of objects, each containing the task 'id', a 'score' (1-100, where 100 is highest priority), and a brief 'reasoning' for the priority.
  
  Tasks:
  ${tasks.map(t => `- [${t.id}] ${t.title}: ${t.description || 'No description'}`).join('\n')}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-lite-preview",
      contents: [{ parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              score: { type: Type.NUMBER },
              reasoning: { type: Type.STRING }
            },
            required: ["id", "score", "reasoning"]
          }
        }
      }
    });

    const result = JSON.parse(response.text || '[]');
    return result;
  } catch (error) {
    console.error("AI Prioritization failed:", error);
    return [];
  }
}
